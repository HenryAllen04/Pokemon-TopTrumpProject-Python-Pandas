# PokemonTopTrumpGame
# Self Made Project
# SinglePlayer

This is my first ever project and my first time using pandas!

The Top Trumps Game works just like the real card game, the program will run untill either the user or AI is left with no cards.
A card is won by having the highest stat! 
