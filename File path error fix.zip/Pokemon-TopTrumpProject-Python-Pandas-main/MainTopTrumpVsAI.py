import ShuffleStats as SS
import Battle as B
import BattleForms as BF

import numpy as np
import pandas as pd
import random

#Note: if decks are cleared manually shuffle() has to be run manually to resolve error

def main():
    SS.shuffle()
    B.readyup()
    

main()
