import os
import os.path

class find_dir:
	def __init__(self):
		self.DIR = os.getcwd()
		self.pokemon_data = self.DIR + '\\pokemon_data.csv'
		self.deck_1 = self.DIR + '\\UserVsAIDecks\\1_Deck.csv'
		self.deck_2 = self.DIR + '\\UserVsAIDecks\\2_Deck.csv'

		a = os.path.exists(self.pokemon_data)
		b = os.path.exists(self.deck_1)
		c = os.path.exists(self.deck_2)

		if a == False or b == False or c == False:
			raise Exception("File directories were not found. Make sure files are in the original places")



if __name__ == '__main__':
	obj = find_dir()
	print(obj.pokemon_data, obj.deck_1, obj.deck_2)
	
